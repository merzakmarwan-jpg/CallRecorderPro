package com.callrecorderpro
import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
class MainActivity: ComponentActivity(){
 private val requestCode=100
 override fun onCreate(b:Bundle?){super.onCreate(b)
  val l=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(32,32,32,32);layoutDirection=LinearLayout.LAYOUT_DIRECTION_RTL}
  val title=TextView(this).apply{text="مسجل المكالمات Pro";textSize=28f;gravity=Gravity.CENTER;setPadding(0,0,0,20)}
  val status=TextView(this).apply{text="جاهز للاختبار — Huawei P30 Pro / EMUI 12";textSize=16f;gravity=Gravity.CENTER;setPadding(0,0,0,20)}
  val start=Button(this).apply{text="بدء التسجيل التجريبي";setOnClickListener{if(hasPermissions()) startRec(status) else ActivityCompat.requestPermissions(this@MainActivity,arrayOf(Manifest.permission.RECORD_AUDIO,Manifest.permission.READ_PHONE_STATE,Manifest.permission.READ_CALL_LOG),requestCode)}}
  val stop=Button(this).apply{text="إيقاف التسجيل";setOnClickListener{stopService(Intent(this@MainActivity,CallRecordingService::class.java));status.text="تم إيقاف التسجيل"}}
  l.addView(title);l.addView(status);l.addView(start);l.addView(stop);setContentView(l)
 }
 private fun startRec(s:TextView){ContextCompat.startForegroundService(this,Intent(this,CallRecordingService::class.java));s.text="التسجيل يعمل"}
 private fun hasPermissions()=arrayOf(Manifest.permission.RECORD_AUDIO,Manifest.permission.READ_PHONE_STATE,Manifest.permission.READ_CALL_LOG).all{ContextCompat.checkSelfPermission(this,it)==PackageManager.PERMISSION_GRANTED}
}
