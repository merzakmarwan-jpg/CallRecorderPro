# CallRecorderPro
نسخة Android تجريبية لتسجيل المكالمات، مهيأة للاختبار على Huawei P30 Pro / EMUI 12.

## Build APK
GitHub > Actions > Build APK > Run workflow. بعد النجاح ستجد APK في Artifacts باسم CallRecorderPro-debug.

مهم: Android وEMUI قد يمنعان التطبيقات من الوصول إلى صوت الطرف الآخر في المكالمة الخلوية. استخدم التسجيل وفق القوانين المحلية واحترم خصوصية جميع الأطراف.
