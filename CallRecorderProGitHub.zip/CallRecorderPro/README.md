# CallRecorderPro
نسخة Android تجريبية لتسجيل المكالمات، مهيأة للاختبار على Huawei P30 Pro / EMUI 12.

## Build APK
GitHub > Actions > Build APK > Run workflow. بعد النجاح ستجد APK في Artifacts باسم CallRecorderPro-debug.

مهم: Android وEMUI قد يمنعان التطبيقات من الوصول إلى صوت الطرف الآخر في المكالمة الخلوية. استخدم التسجيل وفق القوانين المحلية واحترم خصوصية جميع الأطراف.


## Audio format
Recordings are encoded as MP3 (64 kbps) using an Android LAME encoder. The foreground service notification is silent and low-importance; Android may still show a small foreground-service indicator while recording.
