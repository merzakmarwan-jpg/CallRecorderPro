package com.callrecorderpro

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.media.MediaPlayer
import android.os.Bundle
import android.content.SharedPreferences
import android.os.Environment
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.material.card.MaterialCardView
import com.google.android.material.button.MaterialButton

class MainActivity : ComponentActivity() {
    private val requestCode = 100
    private lateinit var statusText: TextView
    private lateinit var statusDot: TextView
    private lateinit var recordingsContainer: LinearLayout
    private var player: MediaPlayer? = null
    private lateinit var prefs: SharedPreferences
    private lateinit var appNameText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("settings", MODE_PRIVATE)
        buildUi()
        refreshRecordings()
    }

    override fun onResume() {
        super.onResume()
        refreshRecordings()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundColor(Color.rgb(247, 248, 252))
        }

        val scroll = ScrollView(this).apply { isFillViewport = true }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(20), dp(18), dp(20), dp(28))
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.RIGHT
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val title = TextView(this).apply {
            text = prefs.getString("record_name", "Huawei Record") ?: "Huawei Record"
            textSize = 27f
            setTextColor(Color.rgb(25, 28, 36))
            setTypeface(Typeface.DEFAULT, Typeface.BOLD)
        }
        val subtitle = TextView(this).apply {
            text = "إدارة تسجيلات المكالمات من مكان واحد"
            textSize = 14f
            setTextColor(Color.rgb(105, 110, 125))
            setPadding(0, dp(4), 0, 0)
        }
        header.addView(title)
        header.addView(subtitle)
        appNameText = title
        content.addView(header, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(18) })

        val statusCard = MaterialCardView(this).apply {
            radius = dp(18).toFloat()
            cardElevation = dp(2).toFloat()
            setCardBackgroundColor(Color.WHITE)
        }
        val statusLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(18), dp(18), dp(18), dp(18))
        }
        statusDot = TextView(this).apply {
            text = "●"
            textSize = 24f
            setTextColor(Color.rgb(108, 114, 128))
            gravity = Gravity.CENTER
        }
        val statusBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.RIGHT }
        val statusTitle = TextView(this).apply {
            text = "حالة التسجيل"
            textSize = 13f
            setTextColor(Color.rgb(105, 110, 125))
        }
        statusText = TextView(this).apply {
            text = "التسجيل متوقف"
            textSize = 18f
            setTypeface(Typeface.DEFAULT, Typeface.BOLD)
            setTextColor(Color.rgb(35, 38, 48))
        }
        statusBox.addView(statusTitle)
        statusBox.addView(statusText)
        statusLayout.addView(statusBox, LinearLayout.LayoutParams(0, -2, 1f))
        statusLayout.addView(statusDot, LinearLayout.LayoutParams(dp(42), dp(42)))
        statusCard.addView(statusLayout)
        content.addView(statusCard, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })

        val start = MaterialButton(this).apply {
            text = "بدء التسجيل"
            textSize = 16f
            isAllCaps = false
            cornerRadius = dp(14)
            setOnClickListener { requestAndStart() }
        }
        content.addView(start, LinearLayout.LayoutParams(-1, dp(56)).apply { bottomMargin = dp(10) })

        val stop = MaterialButton(this).apply {
            text = "إيقاف التسجيل"
            textSize = 15f
            isAllCaps = false
            cornerRadius = dp(14)
            setTextColor(Color.rgb(55, 59, 70))
            setBackgroundColor(Color.WHITE)
            strokeWidth = dp(1)
            strokeColor = android.content.res.ColorStateList.valueOf(Color.rgb(220, 222, 229))
            setOnClickListener {
                stopService(Intent(this@MainActivity, CallRecordingService::class.java))
                setStoppedState()
                refreshRecordings()
            }
        }
        content.addView(stop, LinearLayout.LayoutParams(-1, dp(54)).apply { bottomMargin = dp(22) })

        val settingsTitle = sectionTitle("الإعدادات")
        content.addView(settingsTitle, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })

        val nameCard = MaterialCardView(this).apply {
            radius = dp(14).toFloat()
            cardElevation = 0f
            setCardBackgroundColor(Color.WHITE)
            strokeWidth = dp(1)
            strokeColor = Color.rgb(232, 234, 239)
        }
        val nameLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(15), dp(13), dp(15), dp(13))
        }
        nameLayout.addView(TextView(this).apply {
            text = "اسم التسجيل"
            textSize = 15f
            setTypeface(Typeface.DEFAULT, Typeface.BOLD)
            setTextColor(Color.rgb(38, 41, 50))
        })
        val nameInput = EditText(this).apply {
            setText(prefs.getString("record_name", "Huawei Record") ?: "Huawei Record")
            textSize = 15f
            isSingleLine = true
            hint = "مثال: Huawei Record أو Samsung Record"
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            gravity = Gravity.LEFT
        }
        nameLayout.addView(nameInput, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(6) })
        val saveName = MaterialButton(this).apply {
            text = "حفظ الاسم"
            isAllCaps = false
            cornerRadius = dp(10)
            setOnClickListener {
                val name = nameInput.text.toString().trim()
                if (name.isNotEmpty()) {
                    prefs.edit().putString("record_name", name).apply()
                    appNameText.text = name
                    Toast.makeText(this@MainActivity, "تم حفظ الاسم", Toast.LENGTH_SHORT).show()
                }
            }
        }
        nameLayout.addView(saveName, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(4) })
        nameCard.addView(nameLayout)
        content.addView(nameCard, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(22) })

        val infoTitle = sectionTitle("مصادر المكالمات")
        content.addView(infoTitle, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        content.addView(sourceCard("الهاتف", "المكالمات الخلوية العادية", "متاح حسب قيود الجهاز"))
        content.addView(sourceCard("WhatsApp", "مكالمات الإنترنت", "يعتمد على Android والتطبيق"))
        content.addView(sourceCard("Messenger", "مكالمات الإنترنت", "يعتمد على Android والتطبيق"), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(22) })

        content.addView(sectionTitle("التسجيلات المحفوظة"), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        recordingsContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        content.addView(recordingsContainer)

        val note = TextView(this).apply {
            text = "ملاحظة: تسجيل صوت الطرف الآخر في مكالمات الهاتف أو مكالمات التطبيقات يعتمد على قيود Android وEMUI والجهاز المستخدم."
            textSize = 12f
            setTextColor(Color.rgb(115, 120, 133))
            setPadding(dp(4), dp(18), dp(4), 0)
            gravity = Gravity.RIGHT
        }
        content.addView(note)

        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun sourceCard(name: String, detail: String, state: String): View {
        val card = MaterialCardView(this).apply {
            radius = dp(14).toFloat()
            cardElevation = 0f
            setCardBackgroundColor(Color.WHITE)
            strokeWidth = dp(1)
            strokeColor = Color.rgb(232, 234, 239)
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(15), dp(13), dp(15), dp(13))
        }
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.RIGHT }
        texts.addView(TextView(this).apply { text = name; textSize = 16f; setTypeface(Typeface.DEFAULT, Typeface.BOLD); setTextColor(Color.rgb(38, 41, 50)) })
        texts.addView(TextView(this).apply { text = detail; textSize = 12f; setTextColor(Color.rgb(125, 130, 143)); setPadding(0, dp(2), 0, 0) })
        row.addView(texts, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(TextView(this).apply { text = state; textSize = 11f; setTextColor(Color.rgb(93, 99, 115)); gravity = Gravity.CENTER }, LinearLayout.LayoutParams(dp(120), -2))
        card.addView(row)
        return card.apply { layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) } }
    }

    private fun sectionTitle(text: String) = TextView(this).apply {
        this.text = text
        textSize = 18f
        setTypeface(Typeface.DEFAULT, Typeface.BOLD)
        setTextColor(Color.rgb(35, 38, 48))
        gravity = Gravity.RIGHT
    }

    private fun requestAndStart() {
        val permissions = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_PHONE_STATE)
        if (android.os.Build.VERSION.SDK_INT >= 33) permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = permissions.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), requestCode)
        } else startRecording()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, results: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, results)
        if (requestCode == this.requestCode && results.isNotEmpty() && results.all { it == PackageManager.PERMISSION_GRANTED }) startRecording()
    }

    private fun startRecording() {
        ContextCompat.startForegroundService(this, Intent(this, CallRecordingService::class.java))
        statusText.text = "التسجيل يعمل"
        statusDot.setTextColor(Color.rgb(44, 156, 91))
    }

    private fun setStoppedState() {
        statusText.text = "التسجيل متوقف"
        statusDot.setTextColor(Color.rgb(108, 114, 128))
    }

    private fun refreshRecordings() {
        if (!::recordingsContainer.isInitialized) return
        recordingsContainer.removeAllViews()
        val dir = java.io.File(getExternalFilesDir(Environment.DIRECTORY_MUSIC), "CallRecorderPro")
        val files = dir.listFiles()?.filter { it.isFile && it.extension.equals("mp3", true) }?.sortedByDescending { it.lastModified() }.orEmpty()
        if (files.isEmpty()) {
            recordingsContainer.addView(TextView(this).apply {
                text = "لا توجد تسجيلات محفوظة بعد"
                textSize = 14f
                setTextColor(Color.rgb(120, 125, 138))
                gravity = Gravity.CENTER
                setPadding(0, dp(20), 0, dp(20))
            })
            return
        }
        files.forEach { file -> recordingsContainer.addView(recordingCard(file)) }
    }

    private fun recordingCard(file: java.io.File): View {
        val card = MaterialCardView(this).apply {
            radius = dp(14).toFloat(); cardElevation = 0f; setCardBackgroundColor(Color.WHITE)
            strokeWidth = dp(1); strokeColor = Color.rgb(232, 234, 239)
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), dp(10), dp(12), dp(10)) }
        val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.RIGHT }
        info.addView(TextView(this).apply { text = file.name; textSize = 13f; setTextColor(Color.rgb(45, 48, 58)); setTypeface(Typeface.DEFAULT, Typeface.BOLD) })
        info.addView(TextView(this).apply { text = formatSize(file.length()); textSize = 11f; setTextColor(Color.rgb(125, 130, 143)); setPadding(0, dp(2), 0, 0) })
        row.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
        val play = MaterialButton(this).apply { text = "تشغيل"; isAllCaps = false; minWidth = 0; cornerRadius = dp(10); setPadding(dp(10), 0, dp(10), 0); setOnClickListener { playFile(file) } }
        row.addView(play, LinearLayout.LayoutParams(dp(86), dp(44)))
        card.addView(row)
        return card.apply { layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) } }
    }

    private fun playFile(file: java.io.File) {
        player?.release()
        player = MediaPlayer().apply {
            setDataSource(file.absolutePath)
            prepare()
            start()
            setOnCompletionListener { release(); player = null }
        }
    }

    private fun formatSize(bytes: Long): String = if (bytes < 1024 * 1024) "${bytes / 1024} KB" else "${bytes / (1024 * 1024)} MB"
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onDestroy() { player?.release(); player = null; super.onDestroy() }
}
