package com.callrecorderpro
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telephony.TelephonyManager
import androidx.core.content.ContextCompat
class PhoneStateReceiver:BroadcastReceiver(){override fun onReceive(c:Context,i:Intent){if(i.action!=TelephonyManager.ACTION_PHONE_STATE_CHANGED)return;when(i.getStringExtra(TelephonyManager.EXTRA_STATE)){TelephonyManager.EXTRA_STATE_OFFHOOK->ContextCompat.startForegroundService(c,Intent(c,CallRecordingService::class.java));TelephonyManager.EXTRA_STATE_IDLE->c.stopService(Intent(c,CallRecordingService::class.java))}}}
