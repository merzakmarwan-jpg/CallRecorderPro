package com.callrecorderpro
import android.app.*
import android.content.Intent
import android.media.MediaRecorder
import android.os.*
import java.io.File
class CallRecordingService:Service(){private var r:MediaRecorder?=null
 override fun onCreate(){super.onCreate();val id="call_recording";if(Build.VERSION.SDK_INT>=26)getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel(id,"تسجيل المكالمات",NotificationManager.IMPORTANCE_LOW));startForeground(7,Notification.Builder(this,id).setContentTitle("مسجل المكالمات Pro").setContentText("يتم تسجيل المكالمة").setSmallIcon(android.R.drawable.ic_btn_speak_now).build());try{val d=File(getExternalFilesDir(Environment.DIRECTORY_MUSIC),"CallRecorderPro");d.mkdirs();val f=File(d,"call_${System.currentTimeMillis()}.m4a");r=MediaRecorder().apply{setAudioSource(MediaRecorder.AudioSource.VOICE_COMMUNICATION);setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);setAudioEncoder(MediaRecorder.AudioEncoder.AAC);setAudioEncodingBitRate(128000);setAudioSamplingRate(44100);setOutputFile(f.absolutePath);prepare();start()}}catch(_:Exception){stopSelf()}}
 override fun onDestroy(){try{r?.stop()}catch(_:Exception){};r?.release();r=null;super.onDestroy()}
 override fun onBind(i:Intent?)=null
}
