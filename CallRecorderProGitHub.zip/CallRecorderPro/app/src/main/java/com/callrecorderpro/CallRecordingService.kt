package com.callrecorderpro

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.Environment
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.naman14.androidlame.AndroidLame
import com.naman14.androidlame.LameBuilder
import java.io.File
import java.io.FileOutputStream

class CallRecordingService : Service() {
    private var audioRecord: AudioRecord? = null
    private var androidLame: AndroidLame? = null
    @Volatile private var recording = false
    private var recordingThread: Thread? = null
    private var outputFile: File? = null

    companion object {
        private const val CHANNEL_ID = "call_recording"
        private const val NOTIFICATION_ID = 7
        private const val SAMPLE_RATE = 44100
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        val recordName = getSharedPreferences("settings", MODE_PRIVATE).getString("record_name", "Huawei Record") ?: "Huawei Record"
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle(recordName)
            .setContentText("التسجيل قيد التشغيل")
            .setSilent(true)
            .setOngoing(true)
            .setCategory(Notification.CATEGORY_SERVICE)
            .setShowWhen(false)
            .build()
        startForeground(NOTIFICATION_ID, notification)
        startMp3Recording()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            val channel = NotificationChannel(
                CHANNEL_ID,
                "خدمة التسجيل",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                setSound(null, null)
                enableVibration(false)
                setShowBadge(false)
            }
            manager.createNotificationChannel(channel)
        }
    }

    private fun startMp3Recording() {
        try {
            val minBuffer = AudioRecord.getMinBufferSize(
                SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            )
            if (minBuffer <= 0) throw IllegalStateException("AudioRecord buffer unavailable")

            val bufferSize = maxOf(minBuffer * 2, SAMPLE_RATE / 2)
            val recorder = AudioRecord(
                MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                bufferSize
            )

            val dir = File(getExternalFilesDir(Environment.DIRECTORY_MUSIC), "CallRecorderPro")
            if (!dir.exists()) dir.mkdirs()
            val file = File(dir, "call_${System.currentTimeMillis()}.mp3")
            outputFile = file

            val lame = LameBuilder()
                .setInSampleRate(SAMPLE_RATE)
                .setOutChannels(1)
                .setOutBitrate(64)
                .setOutSampleRate(SAMPLE_RATE)
                .setQuality(5)
                .build()

            audioRecord = recorder
            androidLame = lame
            recording = true

            recordingThread = Thread {
                FileOutputStream(file).use { output ->
                    val pcm = ShortArray(bufferSize / 2)
                    val mp3Buffer = ByteArray(7200 + pcm.size * 2)
                    recorder.startRecording()

                    while (recording) {
                        val read = recorder.read(pcm, 0, pcm.size)
                        if (read > 0) {
                            val encoded = lame.encode(pcm, pcm, read, mp3Buffer)
                            if (encoded > 0) output.write(mp3Buffer, 0, encoded)
                        }
                    }

                    val flushed = lame.flush(mp3Buffer)
                    if (flushed > 0) output.write(mp3Buffer, 0, flushed)
                }
            }.apply { start() }
        } catch (_: Exception) {
            stopSelf()
        }
    }

    override fun onDestroy() {
        recording = false
        try {
            recordingThread?.join(1500)
        } catch (_: InterruptedException) {
        }
        recordingThread = null
        try { audioRecord?.stop() } catch (_: Exception) {}
        audioRecord?.release()
        audioRecord = null
        try { androidLame?.close() } catch (_: Exception) {}
        androidLame = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
